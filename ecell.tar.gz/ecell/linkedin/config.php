<?php
$baseURL = 'http://localhost/ecell/';
$callbackURL = 'http://localhost/ecell/linkedin/process.php';
$linkedinApiKey = '81q03chcewt5ze';
$linkedinApiSecret = 'OwkKwgT1A1vWOLUR';
$linkedinScope = 'r_basicprofile r_emailaddress';
?>